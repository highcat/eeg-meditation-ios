//
//  main.m
//  HelloIOSSeagull
//
//  Created by neurosky on 1/24/14.
//  Copyright (c) 2014 neurosky. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HelloConnectAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HelloConnectAppDelegate class]));
    }
}
