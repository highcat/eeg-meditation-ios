//
//  HelloConnectAppDelegate.h
//  HelloConnect
//
//  Created by neurosky on 1/24/14.
//  Copyright (c) 2014 neurosky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloConnectAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
